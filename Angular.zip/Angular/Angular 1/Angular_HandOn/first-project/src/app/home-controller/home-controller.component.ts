import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-controller',
  templateUrl: './home-controller.component.html',
  styleUrls: ['./home-controller.component.css']
})
export class HomeControllerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
